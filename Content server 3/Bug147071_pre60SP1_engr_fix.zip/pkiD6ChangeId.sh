#!/bin/sh
# ---------------------------------------------------------------------------
# Start script for CsIdentityChanger
# ---------------------------------------------------------------------------
#
# usage A: changeId <docbaseName> <userName> <password>
# usage B: changeId <docbaseName> <userName>
#
# style B will prompt for a password after startup to avoid listing
# the password in the process table, where it may become available to
# unauthorized viewers.
#
# This task will look for an existing dfc.keystore.  If found, it will
# delete it.  If none exists, it will just continue.  The task will next
# create a new keystore, publish the new client identity to the Global
# Registry, and give it rights with the docbase.
#
# Requires a D6 SP1 or later dfc.jar
# Recommended install under $DM_HOME\bin
#
# ---------------------------------------------------------------------------
#
#   Assumed correctly configured environment
#
#      $DOCUMENTUM
#
# the script will source $DOCUMENTUM/product/6.0/bin/dm_set_server_env.sh
#
# ---------------------------------------------------------------------------


TRUE="verbose"
#AUX=$1
VERBOSE=${AUX:="false"}
${DOCUMENTUM:?Environment variable DOCUMENTUM is undefined.  Abort} 2> /dev/null
if [ $VERBOSE = $TRUE ] 
then
    echo "\$DOCUMENTUM is $DOCUMENTUM"
    echo "\$JAVA_HOME is $JAVA_HOME"
    echo "Now setting DM environment . . ."
fi
DM_SET_SERVER_ENV="$DOCUMENTUM/product/6.0/bin/dm_set_server_env.sh"
if [ ! -r $DM_SET_SERVER_ENV ]
then
    echo "No access to file $DM_SET_SERVER_ENV Abort"
    exit 13
fi
if [ $VERBOSE = $TRUE ] 
then
    echo "Sourcing $DM_SET_SERVER_ENV"
fi
. $DM_SET_SERVER_ENV
if [ $VERBOSE = $TRUE ] 
then
    echo "\$DOCUMENTUM is now $DOCUMENTUM"
    echo "\$JAVA_HOME is now $JAVA_HOME"
    echo "\$CLASSPATH is $CLASSPATH"
fi
${CLASSPATH:?Environment variable CLASSPATH is undefined.  Abort} 2> /dev/null
JRE_HOME="${JAVA_HOME:?Environment variable JAVA_HOME is undefined.  Abort}/jre"
if [ ! -d $JRE_HOME/bin ]
then
    echo "$JRE_HOME/bin not found. Abort"
    exit 17
fi

ARCHIVE=./pkiIdChange.jar
if [ ! -r $ARCHIVE ]
then
    echo "No access to archive $ARCHIVE Abort"
    exit 13
fi

ENTRYPT=com.documentum.fc.tools.ncid.CsIdentityChanger

$JRE_HOME/bin/java $JVM_OPTS -classpath $CLASSPATH:$ARCHIVE $ENTRYPT $0 $1 $2 $3
