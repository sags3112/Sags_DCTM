select /* test10 */ r_object_id, object_name from acs53sp4.dm_sysobject_s where r_object_type= 'dm_cabinet';

