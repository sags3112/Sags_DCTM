/*
**  ldap_connect.cpp
**
**  (c) Copyright EMC Corp., 1991 - 2007
**  All rights reserved.
**
**  This is a simple stand alone C++ application that mimics the EMC Documentum
**  Content Server's LDAP user authentication process, with "bind_type" 
**  configured to "search_by_dn", to authenticate users against LDAP directory server.
**
**  This program is intended to be used for troubleshooting EMC Documentum
**  Content Server LDAP user authentication problems.
**
**  This program is intended to use US-ASCII characters only.
**  This program is able to handle NON-SSL as well as SSL LDAP connections.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ldap.h"
#include "ldap_ssl.h"

#define BUFFER_SIZE 1024
#define BAR "=========================================================="

void usage(const char *program_name)
{
  printf("Usage: %s <LDAP Server Host> " \
    "<LDAP Port> " \
    "<UID> " \
    "<User Password> " \
    "<Person Search Base> " \
    "<ssl/nossl> " \
    "<LDAP Admin bind DN> " \
    "<LDAP Admin bind password> " \
    "<LDAP Attr that maps to dm_user user_login_name> " \
    "[/path/to/certdb]\n",
    program_name);
}

int main( int argc, char **argv )
{
  LDAP        *ld = NULL;
  LDAPMessage    *res, *e;
  char        *dn = NULL;
  char        userName[BUFFER_SIZE], filter[BUFFER_SIZE];
  int         i,success,rc,port_no;
  char        obfuscated_password1[BUFFER_SIZE];
  char        obfuscated_password2[BUFFER_SIZE];
  char        certDBPathBuff[BUFFER_SIZE];
  char        *certDBPath;

  memset(userName,0x0,sizeof(userName));
  memset(filter,0x0,sizeof(filter));
  memset(obfuscated_password1,0x0,sizeof(obfuscated_password1));
  memset(obfuscated_password2,0x0,sizeof(obfuscated_password2));
  memset(certDBPathBuff,0x0,sizeof(certDBPathBuff));

  // Check command-line arguments
  if ( argc < 10 ) {
    usage(argv[0]);
    exit( 1 );
  }

  port_no = atoi(argv[2]);

  // BEGIN: print command line arguments
  printf("\n%s\n", BAR);
  printf("%30s: %s\n", "LDAP Host", argv[1]);
  printf("%30s: %d\n", "LDAP Port", port_no);
  printf("%30s: %s\n", "UID", argv[3]);

  // obfuscated_password1 is "User Password" = argv[4]
  for (i=0; 
    (argv[4] != NULL) && (i < strlen(argv[4]) && (i < BUFFER_SIZE)); 
    obfuscated_password1[i]='*', i++);

  //printf(""%-20s: %s\n", "LDAP User password", argv[4]);
  printf("%30s: %s\n", "LDAP User password", obfuscated_password1);

  printf("%30s: %s\n", "Person Search Base", argv[5]);
  printf("%30s: %s\n", "SSL Mode", argv[6]);
  printf("%30s: %s\n", "LDAP Admin Bind DN", argv[7]);

  // obfuscated_password2 is "LDAP_bind_password" = argv[8]
  for (i=0; 
    (argv[8] != NULL) && (i < strlen(argv[8]) && (i < BUFFER_SIZE)); 
    obfuscated_password2[i]='*', i++);

  //printf("%30s: %s\n", "LDAP Admin bind Password", argv[8]);
  printf("%30s: %s\n", "LDAP Admin bind Password", obfuscated_password2);

  printf("%30s: %s\n", "LDAP attr to be searched", argv[9]);

  if (argc == 11 )
  {
    strcpy(certDBPathBuff, argv[10]);
    printf("%30s: %s\n", "File path to cert db", certDBPathBuff);
  }
  // END: print command line arguments

  printf("\n%s\n\n", BAR);

  // check LDAP Bind mode "ssl" or "nossl"
  if ((strcmp(argv[6], "nossl") != 0) && (strcmp(argv[6], "ssl") != 0))
  {
    printf("%20s:    %s: %s\n", "ERROR", "Incorrect LDAP bind mode", argv[6]);
    usage(argv[0]);
    return 1;
  }

  printf("%15s:   %s\n", "BEGIN", "ldap_init()");
  printf("%30s: %s\n", "LDAP Host", argv[1]);
  printf("%30s: %d\n", "LDAP Port", port_no);

  // BEING: get LDAP connection handle
  if (strcmp(argv[6], "nossl") == 0)
  {
    if ( (ld = ldap_init( argv[1], port_no )) == NULL ) 
    {
      printf("%15s:   %s\n", "FAILED", "ldap_init() failed!");
      perror("ldap_init");
      return 1;
    }
    else
    {
      printf("%15s:   %s\n", "DONE", "ldap_init() successful!");
    }
  }
  else if (strcmp(argv[6], "ssl") == 0)
  {
    if ((certDBPathBuff == NULL) || (certDBPathBuff[0] == '\0') || 
      (strlen(certDBPathBuff) == 0))
    {
      certDBPath = getenv("DM_CERT_DB_PATH");

      if ((certDBPath != NULL) && (strlen(certDBPath) > 0))
      {
        memset(certDBPathBuff,0x0,sizeof(certDBPathBuff));
        strncpy(certDBPathBuff, certDBPath, strlen(certDBPath));
      }
      else
      {
        printf("%20s:   %s\n", "ERROR", 
          "Path to certificate store is required " \
          "to establish LDAP SSL connection.\n");
        usage(argv[0]);
        return 1;
      }
    }

    printf("%15s:   %s\n", "BEGIN", "ldapssl_client_init()");
    printf("%30s: %s\n", "File path to cert db", certDBPathBuff);

    if (ldapssl_client_init(certDBPathBuff, NULL ) < 0) 
    {
      printf("%15s:   %s\n", "FAILED", "ldapssl_client_init() failed!");
      perror("ldapssl_client_init");
      return 1;
    }
    else
    {
      printf("%15s:   %s\n", "DONE", "ldapssl_client_init() successful!");
    }

    ld = ldapssl_init( argv[1], port_no, 1);
    if ( ld == NULL )
    {
      printf("%15s:   %s\n", "FAILED", "ldapssl_init() failed!");
      perror("ldapssl_init");
      return 1;
    }
    else
    {
      printf("%15s:   %s\n", "DONE", "ldapssl_init() successful!");
    }
  }
  // END: get LDAP connection handle

  printf("\n%s\n\n", BAR);


  printf("%15s:   %s\n", "BEGIN", "ldap_simple_bind_s()");
  printf("%30s: %s\n", "LDAP Admin Bind DN", argv[7]);

  // obfuscated_password2 is "LDAP_bind_password" = argv[8]
  //printf("%30s: %s\n", "LDAP Admin bind Password", argv[8]);
  printf("%30s: %s\n", "LDAP Admin bind Password", obfuscated_password2);

  //BEGIN: authenticate against directory using "Bind DN" and "LDAP_bind_password"
  if ((rc = ldap_simple_bind_s( ld, argv[7], argv[8])) != LDAP_SUCCESS) {
    printf("%15s:   %s (%s: %d = %s)\n", "FAILED", "ldap_simple_bind_s() failed!", 
      "Return value is", rc, ldap_err2string(rc));

    ldap_perror(ld, "ldap_simple_bind_s");
    return 1;
  }
  else
  {
    printf("%15s:   %s\n", "DONE", "ldap_simple_bind_s() successful!");
  }
  //END: authenticate against directory using "Bind DN" and "LDAP_bind_password"

  printf("\n%s\n\n", BAR);


  printf("\n%s\n\n", BAR);

  // construct LDAP search filter
  strcpy(userName,argv[3]);
  sprintf(filter, "(%s=",argv[9] );
  strcat (filter, userName);
  strcat (filter, ")");

  printf("%15s:   %s\n", "BEGIN", "ldap_search_s()");
  printf("%30s: %s\n", "Search Filter", filter);
  printf("%30s: %s\n", "Search Base", argv[5]);

  // BEGIN: query/search LDAP using "Search Base DN" and "Search Filter" (search scope is "subtree")
  if (ldap_search_s(ld, argv[5], LDAP_SCOPE_SUBTREE,filter, NULL, 0, &res) != LDAP_SUCCESS)
  {
    printf("%15s:   %s\n", "FAILED", "ldap_search_s() failed!");
    ldap_perror(ld, "ldap_search_s");
    return 1;
  }
  else
  {
    printf("%15s:   %s\n", "DONE", "ldap_search_s() successful!");
  }
  // END: query/search LDAP using "Search Base DN" and "Search Filter"

  // BEGIN: loop through LDAP search result set, print found DN
  printf("\n");
  printf("   LDAP Search Result:\n");
  printf("   ------------------\n");

  i = 0;
  for (e = ldap_first_entry(ld, res); e != NULL; e = ldap_next_entry(ld, e),i++ )
  {
    dn = ldap_get_dn( ld, e );
    printf("            Result[%d]: %s\n", i, dn);
  }

  ldap_msgfree( res ); 

  if (i > 1)
  {
    printf("%15s:   Multiple DNs found for user \"%s\" \n", "INFO", userName);
    return 1;
  }

  if ((i == 0) || (dn == NULL))
  {
    printf("%15s:   No entry found in LDAP server for user \"%s\" \n", "INFO", userName);
    return 1;
  }
  // END: loop through LDAP search result set

  printf("\n   -->>Final DN: %s<<--\n", dn);
  printf("\n%s\n\n", BAR);


  printf("\n%s\n\n", BAR);
  printf("%15s:   %s\n", "BEGIN", "ldap_simple_bind_s()");

  printf("%30s: %s\n", "LDAP User DN", dn);

  // obfuscated_password1 is "User Password" = argv[4]
  //printf(""%-20s: %s\n", "LDAP User password", argv[4]);
  printf("%30s: %s\n", "LDAP User password", obfuscated_password1);

  // BEGIN: authenticate against directory server using newly retrieved DN and "User Password"
  rc = ldap_simple_bind_s(ld, dn, argv[4]);
  if (rc != LDAP_SUCCESS)
  {
    printf("%15s:   %s (Reason: %s)\n", "FAILED", 
      "ldap_simple_bind_s() failed!", ldap_err2string(rc));
    ldap_perror(ld, "ldap_simple_bind_s");
    success = 1;
  }
  else
  {
    printf("%15s:   %s\n", "DONE", "ldap_simple_bind_s() successful!");
    printf("\n\n!!! LDAP authentication successful for user \"%s\", i.e. (%s) !!!\n", 
      userName, dn);
    success = 0;
  }
  // END: authenticate against directory server using newly retrieved DN and "User Password"

  printf("\n========================== DONE ==========================\n");

  ldap_memfree( dn );
  return( success );
}
