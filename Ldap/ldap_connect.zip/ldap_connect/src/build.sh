#!/bin/sh
##!/bin/sh -vx

#################################################################
##  File Name: build.sh
##
##  (c) Copyright EMC Corp., 1991 - 2007
##  All rights reserved.
##
##  This is shell script to build Makefile for a simple C++ program 
##  "ldap_connect".
##
##  It is to create "Makefile" based on current UNIX platform and
##  user's environment variables $THIRDPARTY and/or $DM_HOME.
##
##  It then runs "make" to compile, then link/build "ldap_connect".
##
##  "ldap_connect" is a stand alone program that mimics the EMC Documentum
##  Content Server's LDAP user authentication process, with "bind_type" 
##  configured to "search_by_dn", to authenticate users against LDAP directory server.
##
##  "ldap_connect" is intended to be used for troubleshooting EMC Documentum
##  Content Server LDAP user authentication problems.
##
##
#################################################################


#################################################################
# set interactive to 0 to disable prompting for user input
# set interactive to 1 to enable prompting for user input
#################################################################
interactive=0

#################################################################
# determine current platform
#################################################################
uname=`uname -s`
if [ "${uname}" != "HP-UX" ] && [ "${uname}" != "AIX" ] && 
   [ "${uname}" != "SunOS" ] && [ "${uname}" != "Linux" ]
then
	echo "!!! Platform ${uname} is not supported !!!"
	exit 1
fi

#################################################################
# determine current directory
#################################################################
PWD=`dirname $0 | pwd`

#################################################################
# determine variable values in Makefile
#################################################################
CC=cc
platform=
nspr_lib_path=
netscape_lib_path=
nss_lib_path=
opt_flag=-g
extra_link_flags=
THIRDPARTY="${THIRDPARTY}"
DM_HOME="${DM_HOME}"

#################################################################
# Makefile variable and values for HP-UX platform
#################################################################
uname_m=`uname -m`
if [ "${uname}" = "HP-UX" ]
then
	CC=/opt/aCC/bin/aCC
	platform=hp
	extra_link_flags="-Wl,+s -ldld  -lV3  -lsec  -lpthread"
	if [ "${uname_m}" = "ia64" ]
	then
		platform=hpuxia64_32
	fi
	extra_link_flags="-Wl,+s -ldld  -lsec  -lpthread"
	PWD=`dirname $0 | pwd`
fi

#################################################################
# Makefile variable and values for AIX platform
#################################################################
if [ "${uname}" = "AIX" ]
then
	CC=/usr/vacpp/bin/xlC
	platform=aix
	extra_link_flags="-Wl,-brtl"
	PWD=`ksh whence -p $0 | dirname`
fi

#################################################################
# Makefile variable and values for SunOS/Solaris platform
#################################################################
if [ "${uname}" = "SunOS" ]
then
	CC=/opt/SUNWspro/bin/CC
	platform=sun5
	extra_link_flags="-g" 
	PWD=`ksh whence -p $0 | dirname`
fi

#################################################################
# Makefile variable and values for Linux platform
#################################################################
if [ "${uname}" = "Linux" ]
then
	CC=/usr/bin/g++
	platform=linux
	#extra_link_flags="-Wl,-brtl"
	extra_link_flags="-ldl -Wl,-Bdynamic -Wl,--noinhibit-exec"
	PWD=`dirname $0 | pwd`
fi

#################################################################
# determine $THIRDPARTY
#################################################################
if [ "${THIRDPARTY}" = "" ] && [ "${DMNEW}" != "" ] && 
   [ -d "${DMNEW}" ] && [ -d "${DMNEW}/thirdparty" ]
then
	THIRDPARTY="${DMNEW}/thirdparty"
fi

if [ "${THIRDPARTY}" = "" ] && [ "${dmnew}" != "" ] && 
   [ -d "${dmnew}" ] && [ -d "${dmnew}/thirdparty" ]
then
	THIRDPARTY="${dmnew}/thirdparty"
fi

#################################################################
# nspr_lib_path, netscape_lib_path, and nss_lib_path
# depends on $THIRDPARTY value
#################################################################
nspr_lib_path=
netscape_lib_path=
nss_lib_path=

#################################################################
# if $THIRDPARTY is undefined, check if $DM_HOME is defined,
# otherwise, prompt user for input
#################################################################
if [ "${DM_HOME}" != "" ]  && [ -d "${DM_HOME}/bin" ]
then
	nspr_lib_path="${DM_HOME}/bin"
	netscape_lib_path="${DM_HOME}/bin"
	nss_lib_path="${DM_HOME}/bin"
else
	if [ "${THIRDPARTY}" = "" ] || [ ! -d "${THIRDPARTY}" ]
	then
		while [ "${interactive}" = "1" ]
		do
			echo "Please enter path to thirdparty libaries " \
			     "(i.e. \$DMNEW/thirdparty ): "
			read THIRDPARTY

			if [ ! -d "${THIRDPARTY}" ]
			then
				echo "Directory ${THIRDPARTY} does not exist. Try again. "
			else
				break
			fi
		done
	fi

	if [ "${THIRDPARTY}" != "" ] && [ -d "${THIRDPARTY}" ] &&
	   [ -d "${THIRDPARTY}/netscape/nspr/${platform}" ]
	then
		nspr_lib_path=${THIRDPARTY}/netscape/nspr/${platform}
	fi

	if [ "${THIRDPARTY}" != "" ] && [ -d "${THIRDPARTY}" ] &&
	   [ -d "${THIRDPARTY}/netscape/unix/${platform}" ]
	then
		netscape_lib_path=${THIRDPARTY}/netscape/unix/${platform}
	fi

	if [ "${THIRDPARTY}" != "" ] && [ -d "${THIRDPARTY}" ] &&
	   [ -d "${THIRDPARTY}/netscape/nss/${platform}" ]
	then
		nss_lib_path=${THIRDPARTY}/netscape/nss/${platform}
	fi

fi

LDAP_CONNECT_EXEC=ldap_connect_${platform}
Makefile_Name=Makefile_${platform}
Makefile_Name_bk=${Makefile_Name}.`date '+%Y_%m_%d_%H_%M'`.bak


#################################################################
# before creating Makefile, check if one already exists
# if yes, prompt user what he wants to do:
# 1) overwrite original Makefile
# 2) back up original Makefile
#################################################################
if [ -f ${Makefile_Name} ]
then
	while [ "${interactive}" = "1" ]
	do
		#########################################
		# use date timestamp to name backup file
		#########################################

		echo "Makefile \"${Makefile_Name}\" already exist. "
		echo "Do you want to ..."
		echo " "
		echo "1. Overwrite original Makefile with new Makefile"
		echo "2. Backup original \"${Makefile_Name}\" " \
		     "to \"${Makefile_Name_bk}\" "
		echo " "
		echo "Please enter 1 or 2: "
		read action

		#########################################
		# only accept values "1" or "2"
		#########################################
		if [ "$action" != "2" ] && [ "$action" = "1" ]
		then
			echo "${action} is not a valid answer.  Please try again."
		fi

		#########################################
		# option 1 is to overwrite original
		#########################################
		if [ "$action" = "1" ]
		then
			echo "Original make file ${Makefile_Name} will be overwritten"
			break
		fi

		#########################################
		# option 2 is to backup original
		#########################################
		if [ "$action" = "2" ]
		then

			#########################################
			# rename original make file to back up file
			#########################################

			/bin/mv ${Makefile_Name} ${Makefile_Name_bk}

			echo "Original make file \"${Makefile_Name}\" has been " \
			     "renamed to \"${Makefile_Name_bk}\""
		     	break
		fi
	done
fi

######################################################
## begin creating Makefile
######################################################

echo " "
echo "`date '+%Y-%m-%d %H:%M:%S %Z':` BEGIN creating ${Makefile_Name} ..."
echo " "

touch ${Makefile_Name}

echo " " >> ${Makefile_Name}
echo "###########################################################" > ${Makefile_Name}
echo "#  " >> ${Makefile_Name}
echo "# File Name: ${Makefile_Name} " >> ${Makefile_Name}
echo "# Date: `date '+%Y-%m-%d %H:%M:%S %Z'`" >> ${Makefile_Name}
echo "# Purpose:  " >> ${Makefile_Name}
echo "#      This is makefile to build ${LDAP_CONNECT_EXEC} " \
     "for ${uname} platform" >> ${Makefile_Name}
echo "#  " >> ${Makefile_Name}
echo "###########################################################" >> ${Makefile_Name}

echo " " >> ${Makefile_Name}
echo "INCLUDE_DIR=${PWD}/hdr" >> ${Makefile_Name}

echo " " >> ${Makefile_Name}
echo "EXTRA_LD_FLAGS=${extra_link_flags}" >> ${Makefile_Name}

echo " " >> ${Makefile_Name}
echo "OPT_FLAG=${opt_flag}" >> ${Makefile_Name}

echo " " >> ${Makefile_Name}
echo "CFLAGS=\$(OPT_FLAG) -I\$(INCLUDE_DIR)" >> ${Makefile_Name}

echo " " >> ${Makefile_Name}
echo "NSPR_LIB_DIR=${nspr_lib_path} " >> ${Makefile_Name}

echo " " >> ${Makefile_Name}
echo "NETSCAPE_LIB_DIR=${netscape_lib_path} " >> ${Makefile_Name}

echo " " >> ${Makefile_Name}
echo "NSS_LIB_DIR=${nss_lib_path} " >> ${Makefile_Name}

echo " " >> ${Makefile_Name}
echo "LIBS=-L\$(NSPR_LIB_DIR) -lnspr4 " \
     "-L\$(NETSCAPE_LIB_DIR) -lldap50 -lssldap50 -lprldap50 " \
     "-L\$(NSS_LIB_DIR) -lnss3 -lssl3" >> ${Makefile_Name}
echo " " >> ${Makefile_Name}

echo "CC=${CC} " >> ${Makefile_Name}
echo " " >> ${Makefile_Name}

echo "all:	${LDAP_CONNECT_EXEC}" >> ${Makefile_Name}
echo " " >> ${Makefile_Name}

echo "ldap_connect.o:" >> ${Makefile_Name}
echo "	\${CC} \${CFLAGS} -c ldap_connect.cpp" >> ${Makefile_Name}
echo " " >> ${Makefile_Name}

echo "${LDAP_CONNECT_EXEC}:	ldap_connect.o" >> ${Makefile_Name}
echo "	\${CC} -o ${LDAP_CONNECT_EXEC} ldap_connect.o \$(EXTRA_LD_FLAGS) \$(LIBS)" >> ${Makefile_Name}
echo " " >> ${Makefile_Name}

echo "clean:" >> ${Makefile_Name}
echo "	/bin/rm -f ${LDAP_CONNECT_EXEC} ldap_connect.o " >> ${Makefile_Name}
echo " " >> ${Makefile_Name}

echo " " >> ${Makefile_Name}

echo " "
cat -n ${Makefile_Name}

echo "`date '+%Y-%m-%d %H:%M:%S %Z':` DONE creating ${Makefile_Name} ..."
echo " "

echo " "
echo "`date '+%Y-%m-%d %H:%M:%S %Z':` BEGIN make -f ${Makefile_Name} clean ..."
echo " "

cd ${PWD}
make -f ${Makefile_Name} clean

echo " "
echo "`date '+%Y-%m-%d %H:%M:%S %Z':` DONE make -f ${Makefile_Name} clean ..."
echo " "

echo " "
echo "`date '+%Y-%m-%d %H:%M:%S %Z':` BEGIN make -f ${Makefile_Name} ${LDAP_CONNECT_EXEC} ..."
echo " "

cd ${PWD}
make -f ${Makefile_Name} ${LDAP_CONNECT_EXEC}

echo " "
echo " `date '+%Y-%m-%d %H:%M:%S %Z':` DONE make -f ${Makefile_Name} ${LDAP_CONNECT_EXEC} ..."
echo " "






