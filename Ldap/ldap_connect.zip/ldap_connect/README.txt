
File Name: README.txt

(c) Copyright EMC Corp., 1991 - 2007
All rights reserved.

This is README file for "ldap_connect."

"ldap_connect" is stand alone C++ program that mimics the EMC Documentum
Content Server's LDAP user authentication process, with "bind_type" 
configured to "search_by_dn", to authenticate users against LDAP directory server.

"ldap_connect" is intended to be used for troubleshooting EMC Documentum
Content Server LDAP user authentication problems.


Files in this directory:
========================

$/ldap_connect/:
	ldap_connect.sln (Microsoft Visual C++ Solution file)
	ldap_connect.vcproj (Microsoft Visual C++ Project file)
	README.txt (this file)

$/ldap_connect/bin:
	ldap_connect.exe ("ldap_connect" program for Windows platform)
	ldap_connect_aix ("ldap_connect" program for IBM AIS platform)
	ldap_connect_hp ("ldap_connect" program for HP-UX platform)
	ldap_connect_hpuxia64_32 ("ldap_connect" program for HP IA 64 platform)
	ldap_connect_linux ("ldap_connect" program for RedHat Linux platform)
	ldap_connect_sun5 ("ldap_connect" program for SunOS/Solaris platform)
	run.bat (wrapper script for "ldap_connect", for Windows platform)
	run.sh (wrapper script for "ldap_connect", for all UNIX platforms)

$/ldap_connect/libs:
	nsldap32v50.lib (required libary for buildding/linking ldap_connect, for Windows)
	nsldappr32v50.lib (required libary for buildding/linking ldap_connect, for Windows)
	nsldapssl32v50.lib (required libary for buildding/linking ldap_connect, for Windows)
	
$/ldap_connect/src:
	build.sh  (shell script to build "ldap_connect" on UNIX platform)
	ldap_connect.cpp (main source code for "ldap_connect" program)

$/ldap_connect/src/header:
	lber.h (required header file for compiling "ldap_connect")
	ldap.h (required header file for compiling "ldap_connect")
	ldap_ssl.h (required header file for compiling "ldap_connect")
	


To build ldap_connect on UNIX:
==============================
Edit shell script $ldap_connect/src/build.sh
Make sure the path to compiler is correctly specified, i.e. the variable CC
Make sure the variable "DM_HOME" is set to correctly as well.
chmod 755 build.sh

Then run "build.sh" from command line to make "Makefile".
The shell script "build.sh" will create a "Makefile", then calls "make" to build "ldap_connect".

If the build is successful, you will find "Makefile_platform", "ldap_connect.o", 
and "ldap_connect_platform" in the $/ldap_connect/src/ directory.

To run ldap_connect on UNIX:
============================
A wrapper script "run.sh" is included in this package under $/ldap_connect/bin.

Edit this shell script to fit the customer/test LDAP connection configuration.

Make sure the follwing config values are specified correctly in "run.sh":
SSL_MODE=nossl
LDAP_HOST=ldap.company.com
LDAP_PORT=389
LDAP_USER_UID="jsmith"
LDAP_USER_PASSWORD="secret"
PERSON_SEARCH_BASE="ou=people, dc=company, dc=com"
LDAP_ADMIN_BIND_DN="ldap_dmadmin"
LDAP_ADMIN_BIND_PASSWORD="admin_password"
LDAP_ATTR_TO_BE_SEARCHED="uid"


To build ldap_connect on Windows:
=================================

Open Solution file "$/ldap_connect/ldap_connect.sln" in Microsoft Visual Studio .Net IDE.
High light project "ldap_connect" in Solution Explorer.
Select "Build" to build project.
If build is successful, the newly built "ldap_connect.exe" executable can be found 
under $/ldap_connect/Debug/ldap_connect.exe

To debug and run "ldap_connect" in Microsoft Visual Studio .Net:
================================================================
High light project "ldap_connect" in Solution Explorer.
Right click mouse to select "Properties"
In the "ldap_connect Property Pages" pop up window, select "Debugging", in 
the "Action" section displayed in main panel, for "Command Arguments", please enter:
"<LDAP_HOST>" "<LDAP_PORT>" "<LDAP_USER>" "<LDAP_USER_PASSWORD>" "<PERSON_SEARCH_DN>" "nossl" "<LDAP_ADMIN_DN>" "<LDAP_ADMIN_PASSWORD>" "<LDAP_ATTR_MAP_TO_MD_USER_LOGIN_NAME>"

For example:
"ldap.company.com" "389" "jsmith" "secret" "ou=people, dc=company, dc=com" nossl "ldap_admin" "admin_password" "uid"

Click "OK" to save changes.

Open Source File "ldap_connect.cxx" in Microsoft Visual Studio .Net.
Set break point inside function main(), preferbably the first line of code in main().
Press "F5" to start debugging the program.
Press "F10" to step over code when program stops at break point.

Feel free to make change to this program for testing purpose.

NOTE:
====
$/ldap_connect/bin/run.bat is a wrapper script that sets all the LDAP configuration variables.
Edit "run.bat" to specify LDAP configuration to fit your needs.
Then run "run.bat" to launch "ldap_connect" from command line.



SAMPLE OUTPUT:
==============

wud2@pleoski:[/disks/dagger4/wud2/tmp/src]> ./run_me.sh

2007-11-26 15:32:15 PST: BEGIN Running the following command ...

./ldap_connect_sun5 us201.dctmlabs.com 32644 jwalker Pleasanton01 ou=people, dc=dctmlabs, dc=com nossl cn=Directory Manager admin123 uid /disks/dagger4/wud2/tmp/src/ldapdb

==========================================================
                     LDAP Host: us201.dctmlabs.com
                     LDAP Port: 32644
                           UID: jwalker
            LDAP User password: ************
            Person Search Base: ou=people, dc=dctmlabs, dc=com
                      SSL Mode: nossl
            LDAP Admin Bind DN: cn=Directory Manager
      LDAP Admin bind Password: ********
      LDAP attr to be searched: uid
          File path to cert db: /disks/dagger4/wud2/tmp/src/ldapdb

==========================================================

          BEGIN:   ldap_init()
                     LDAP Host: us201.dctmlabs.com
                     LDAP Port: 32644
           DONE:   ldap_init() successful!

==========================================================

          BEGIN:   ldap_simple_bind_s()
            LDAP Admin Bind DN: cn=Directory Manager
      LDAP Admin bind Password: ********
           DONE:   ldap_simple_bind_s() successful!

==========================================================


==========================================================

          BEGIN:   ldap_search_s()
                 Search Filter: (uid=jwalker)
                   Search Base: ou=people, dc=dctmlabs, dc=com
           DONE:   ldap_search_s() successful!

   LDAP Search Result:
   ------------------
            Result[0]: uid=jwalker, ou=People, dc=dctmlabs,dc=com

   -->>Final DN: uid=jwalker, ou=People, dc=dctmlabs,dc=com<<--

==========================================================


==========================================================

          BEGIN:   ldap_simple_bind_s()
                  LDAP User DN: uid=jwalker, ou=People, dc=dctmlabs,dc=com
            LDAP User password: ************
           DONE:   ldap_simple_bind_s() successful!


!!! LDAP authentication successful for user "jwalker", i.e. (uid=jwalker, ou=People, dc=dctmlabs,dc=com) !!!

========================== DONE ==========================

2007-11-26 15:32:15 PST: END Running command ...



wud2@pleoski:[/disks/dagger4/wud2/tmp/src]>



