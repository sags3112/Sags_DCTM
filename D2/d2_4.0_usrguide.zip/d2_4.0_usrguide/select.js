function doInit()
{
    var ua = window.navigator.userAgent;
    var msie = ua.indexOf ( "MSIE " );
    var ver;

    if ( msie > 0 )        // is Microsoft Internet Explorer; return version number
        ver = parseInt ( ua.substring ( msie+5, ua.indexOf ( ".", msie ) ) );

    var kArray = window.dialogArguments;

    if (kArray == null)
    {
        window.alert("No selections passed");
        window.close();
    }
    else
    {
        var kindexHTML;
        for (var i=0; i < kArray.length; i++)
        {
            if (kArray[i].getAttribute("href") == null)
                continue;
            if (kArray[i].getAttribute("name") == null)
                continue;
            kindexHTML = '<DIV HREF="' + kArray[i].getAttribute("href") + '">'
                         + kArray[i].getAttribute("name") + '</A>';
            document.body.insertAdjacentHTML("beforeEnd", kindexHTML);
        }
    }
}

function doClick()
{
    var parentDiv = window.event.srcElement;

    window.returnValue = parentDiv.getAttribute("href");
    window.close();
}

