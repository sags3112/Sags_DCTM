var recordSelect = true;
var bMSIE, bMSIE3, bMSIE4, bMSIE5, bMSIE4_beta, bMSIE4_01;
var bNetscape, bNetscape_2, bNetscape_3, bNetscape_4;

// Before finishing the load, let us see if we need to build
// the frame.

if (window.parent == self)
{
	// Need to build the frame
	// So where are we?
	var hrefTarget = document.location.pathname;

	if (hrefTarget.lastIndexOf("/") != 0)
	{
		hrefTarget = hrefTarget.substring(hrefTarget.lastIndexOf("/")+1);
	}
	browser();
	if (bMSIE3)
	{
		open("default.htm?startat="+hrefTarget+document.location.search, "_top");
	}
	else
	{
		document.location.replace("default.htm?startat="+hrefTarget+document.location.search);
	}
}

// Must not be rebuilding.

function browser()
{
	// borrowed from Microsoft
    var ua = navigator.userAgent;
    var an = navigator.appName;

    // Is it IE?
    bMSIE = (ua.indexOf("MSIE")>=1);
    if (bMSIE)
    {
        // IE3
        bMSIE3 = (ua.indexOf("MSIE 3.0")>=1);

        // IE4
        var iMSIE4 = ua.indexOf("MSIE 4.0");
        bMSIE4 = (iMSIE4>=1);
        if (bMSIE4)
        {
            var sMinorVer = ua.charAt(iMSIE4+8);
            // Some folks are still running an IE4 beta!
            // (the Mac IE team used a 'p' to mark their beta)
            bMSIE4_beta = bMSIE4 && ((sMinorVer == "b") || (sMinorVer == "p"));

            // IE4.01
            bMSIE4_01 = bMSIE4 && (sMinorVer == "1");
        }
        // IE5
        bMSIE5 = (ua.indexOf("MSIE 5.0")>=1);
    }
    else if (an == "Netscape")
    {
        bNetscape = true;
        appVer = parseInt(navigator.appVersion);
        if (appVer >= 4)
            bNetscape_4 = true;
        else if (appVer >= 3)
            bNetscape_3 = true;
        else
            bNetscape_2 = true;
    }
}

function newPage(pageHREF)
{
	var navFrame = window.parent.frames["NAV"];
	if (navFrame == null)
		return;
	if (navFrame.document.readyState == null)
		return;
	if (navFrame.document.readyState != "complete")
		return;
	navFrame.doNewTextPage(pageHREF);
}

function newSelection()
{
	// Don't allow double clicks if this is not loaded via HTTP
	if (document.location.protocol != "http:" && document.location.protocol != "https:" )
	{
		return;
	}

	if (recordSelect == false)
		return;

	var navFrame = window.parent.frames["NAV"];
	if (navFrame == null)
		return;
	if (navFrame.document.readyState == null)
		return;
	if (navFrame.document.readyState != "complete")
		return;
	for (var targetElement = window.event.srcElement;
			targetElement != null;
			targetElement = targetElement.parentElement)
	{
		if (targetElement.getAttribute("srctreeloc") != null)
		{
			navFrame.textSelection(targetElement);
			window.event.cancelBubble = true;
			return;
		}
	}
	window.event.cancelBubble = true;
}

function gettingFocus()
{
	if (window.event.srcElement == window.document.body)
		return;
	recordSelect = true;
}

function losingFocus()
{
	if (window.event.srcElement == window.document.body)
		return;
	recordSelect = false;
}

// From here down is to handle footnotes

var curShowingId = null;
var defaultWidth = 300;

function showFootnote(evt, id) {
	var div = document.getElementById(id);
	if (!div) return;

	// Get the body
	var body = document.documentElement.scrollTop ? document.documentElement : document.body;

	// Unfortunately, gotta do some work to be cross-browser.
	var pageX = 0;
	var pageY = 0;
	if (document.all) {
		// IE version
		pageX = evt.clientX + body.scrollLeft;
		pageY = evt.clientY + body.scrollTop;
	}
	else {
		/* Mozilla version */
		pageX = evt.pageX;
		pageY = evt.pageY;
	}
	div.style.top = pageY;
	div.style.left = pageX;

	// Only show 1 at a time.
	hideActiveFootnote();

	div.style.display = 'block';
	curShowingId = id;

	// Now we do some fancy stuff; all this is optional but
	// useful.

	// Figure spacial relationships
	var winY = evt.clientY;
	var height = div.clientHeight;
	var spaceBelow = body.clientHeight - winY;
	var spaceAbove = winY;

	var winX = evt.clientX;
	var width = div.clientWidth;
	var spaceRight = body.clientWidth - winX;
	var spaceLeft = winX;
    
	// Place it to the left or right depending on where there's room.
    if (width > spaceRight && spaceLeft > spaceRight) {
		if (width > spaceLeft) {
			div.style.width = spaceLeft;
		}
		div.style.left = pageX - div.clientWidth;
		shadowLeft = (pageX - div.clientWidth) + 5;
	}
	else if (width > spaceRight) {
		// If there's more space on the right but we need to
		// shrink
		div.style.width = spaceRight;
	}

	// We want to place it above if it's too tall to
	// fit below and there's more room above.
	if (height > spaceBelow && spaceAbove > spaceBelow) {
		if (height > spaceAbove) {
			// Shrink it vertically.
			div.style.height = spaceAbove;
		}
		div.style.top = pageY - div.clientHeight;

	}
	else if (height > spaceBelow) {
		div.style.height = spaceBelow;
	}


	// Show the dropshadow.  Frivolous, but neat.
	var shadow = getShadow();
	shadow.style.left = parseInt(div.style.left) + 5;
	shadow.style.top = parseInt(div.style.top) + 5;
	shadow.style.width = div.offsetWidth;
	shadow.style.height = div.offsetHeight;
	shadow.style.display = 'block';
}

function hideActiveFootnote() {
	if (curShowingId) {
		var div = document.getElementById(curShowingId);
		// Resize dynamic height.
		div.style.display = 'none';
		div.style.height = '';
		div.style.width = defaultWidth;
		curShowingId = null;

		getShadow().style.display = 'none';
	}
}

function targetInFootnoteLink(el) {
	if (!el) return false;
	for (;el && el.className != 'footnoteref'; el = el.parentNode);
	return el && el.className == 'footnoteref';
}

// Whenever the user clicks somewhere other than a footnoteref,
// hide the footnoteref.
document.onclick = function(evt) {
	if (!evt) evt = window.event;

	// Again, browser inconsistencies; IE uses srcElement.
	var target = evt.srcElement ? evt.srcElement : evt.target;
	if (!target || !targetInFootnoteLink(target)) {
		hideActiveFootnote();
	}
}

function getShadow() {
	var shadow = document.getElementById("dropshadow");
	if (!shadow) {
		shadow = document.createElement("div");
		shadow.setAttribute("id", "dropshadow");
		var body = document.body.scrollTop ? document.body : document.documentElement.getElementsByTagName("body")[0];
		if (body) {
			body.appendChild(shadow);
		}
	}
	return shadow;
}

function doResize(evt) {
	//hideActiveFootnote();
}


// Always hide on scroll and resize
// (doesn't work with scrollwheel on Mozilla).
window.onresize = doResize;
window.onscroll = function() {hideActiveFootnote();};


//*****************************************************************************
// ProductView
//*****************************************************************************
function NSInitialised(ctl, file)
{
    window.setTimeout("_NSInitialised('"+ctl+"','"+file+"')",0);
}
function _NSInitialised(ctl, file)
{
  if (file.indexOf("http:") == 0 ||
      file.indexOf("https:") == 0 ||
      file.indexOf("file:") == 0) {
    path = file;
  }
  else {
    // ProductView needs "file:\\\", but it doesn't want spaces to turn to %20
    var loc = decodeURI(window.location);
    var path =loc.slice(0, loc.lastIndexOf('/')) + '/' + file;
  }
  var ctrl = document.getElementById(ctl);
  ctrl.SetSrc(path);      
}
function NSLoadEdComplete(ctl, view)
{
    window.setTimeout("_NSLoadEdComplete('"+ctl+"','"+view+"')",0);
}

function _NSLoadEdComplete(ctl, view)
{
  // If a link from another document specifies a view-state, change the
  // view-state accordingly
  if (parent.pvObjectName == ctl) {
    view = parent.pvViewState;
    parent.pvObjectName = "";
  }

  var ctrl = document.getElementById(ctl);
  ctrl.LoadModel(view == "Default" ? "" : view);
  ctrl.SetPropValueInt("model/clrBkg", 0xffffff);
  ctrl.SetPropValueInt("model/clrGradient", 0xffffff);
}

// When the link jumps to another document, store link data, so when the
// target document is brought up, the target 3D graphic will change its
// view-state based on the link.
function NSStoreLink(name, view)
{
  parent.pvObjectName = name;
  parent.pvViewState = view;
}

// When the link target is in the same document, directly use the control
// to change view-state based on the link.
function NSOnClick(ctl, view)
{
  var ctrl = document.getElementById(ctl);
  if (ctrl != null)
    {
      window.setTimeout("_NSOnClick('"+ctl+"','"+view+"')",700);
    }
  else
    {
      NSStoreLink(ctl, view)
    }
}

function _NSOnClick(ctl, view)
{
  var ctrl = document.getElementById(ctl);
  ctrl.LoadModel(view == "Default" ? "" : view);
}

// //////////////////////////////////////////////////////////////
// determine which browser we are running in - this global
// value _isIE is used elsewhere in the pvcadview scripts
// //////////////////////////////////////////////////////////////
var _isIE = false;
var _is64bitIE = false;
var _isNS6 = false;
var ver = navigator.appVersion;
if (ver.indexOf("MSIE") != -1)
{
  _isIE=true;
  if (ver.indexOf("Win64") != -1)
  {
        _is64bitIE = true;
  }
}
if (ver.indexOf("5.0") == 0)
  _isNS6=true;

// //////////////////////////////////////////////////////////////
// document-specific functions
// //////////////////////////////////////////////////////////////
var _docType="application/x-pvlite8-ed";
			  // defines the type of viewable (drawing or model)
var _docPluginVersion;	  // version string of the form '1.2.3.4'
var _docPluginURL;	  // version string of the form '1.2.3.4'
var _docPluginID;
var _docAction;
var _docURL;
var _docOnLoadOverride;
var _docColorOption;
var _docViewOrientationOption;
var _docAdditionalOption;
var _urllist;
var _local_UpgradeTitle = "A new version of ProductView Lite is available for download";
var _local_UpgradeContinue = "Use current version";
var _local_UpgradeInstall = "Install new version";
var _local_Install="Install ProductView Lite";
var _local_Enable_SoftwareUpdate = "You must enable Software Update to install this plugin";
var _local_Install_Failed = "ProductView Lite installation failed";
var _local_Unsupported_Browser = "Unsupported browser platform";
var _local_InitialisePlugin_Error = "An error occured initialising the ProductView Lite plugin";
var _local_Restart_Needed = "You need to restart your browser to complete the ProductView Lite installation"

function PV_InsertPlugin(width, height, downloaddir, versionstrings, pluginID)
{
  var _showEmbed=true;
  var _showImage=false;
  var _showUpgrade=false;
  var _showInstallLink=false;
  var _showReboot=false;
  var vi;
  var _browser_type = "";
  var _browser_platform = "";
  var _imageOnly = false;
  
  if (pluginID) _docPluginID = pluginID;
  
  if (navigator.platform == "SunOS sun4u")
  {
    _browser_platform="sun4_solaris";
  }
  if (navigator.platform == "SunOS i86pc")
  {
    _browser_platform="sun_solaris_x32";
  }
  if (navigator.platform == "Win32")
  {
    if (_is64bitIE)
      _browser_platform = "x86e_win64";
    else
      _browser_platform = "i486_nt";
  }
  if (navigator.platform.substring(0,5) == "HP-UX")
  {
    _browser_platform = "hpux11_pa32";
  }
  if (navigator.platform.substring(0,3) == "AIX")
  {
    _browser_platform = "ibm_rs6000";
  }
  if (_browser_platform == "")
  {
        if (typeof _pvliteString_Unsupported_Browser != "undefined")
        {
         _local_Unsupported_Browser = _pvliteString_Unsupported_Browser;
        }
        window.alert(_local_Unsupported_Browser +"\n" + navigator.platform);
        return;
  }
  if (navigator.appName == "Netscape")
  {
    _browser_type = "ns";
  } else
  {
    _browser_type = "ie";
  }
  if (_browser_type == "" || _browser_platform == "")
  {
    _imageOnly = true;
  } else
  {
    var _browser = _browser_platform + "_" + _browser_type + "/";
    var vs = versionstrings;
    while(true) 
    {
      var loc = vs.indexOf(";");
      var v = loc!=-1?vs.substring(0,loc):vs;
      if( v.indexOf(_browser) == 0 ) {
        var versionLoc = v.lastIndexOf('/');
        _docPluginVersion = v.substring(versionLoc+1);
        _docPluginURL = v.substring(0,versionLoc);
      }
      if( loc == -1 ) break;
      vs = vs.substring(loc+1);
    }
  }
  if (_isIE) 
  {
    // write object tag for Internet Explorer
    if (_is64bitIE)
    {
        document.write('<object classid="CLSID:54a51802-9749-412e-b48c-5908bb503a18"');
    } else
    {
        document.write('<object classid="CLSID:050A0128-BE56-4f4b-9F2A-2F926AB5A2F2"');
    }
    if (_docPluginID) document.write('id="' + _docPluginID + '"');
    else              document.write('id="pvctl"');
    if (_docType) document.write(' type="' + _docType + '"');

  if (downloaddir != "")
  {
    if (_docPluginURL) document.write(' codebase="' + downloaddir + "/" + _docPluginURL);
    if (_docPluginVersion) document.write('#version=' + _docPluginVersion);
    if (_docPluginURL) document.write('"');
  }

    if (width) document.write(' width="' + width + '"');
    if (height) document.write(' height="' + height + '"');
    document.write('>\n');

  if (downloaddir != "")
  {
    document.write('<param name="pviewdownloadurl" value="' + downloaddir + '">');
  }

    document.write('</object>\n');
  }
}
        

function pview_Insert(pluginID, filename,
		      viewstate,
		      width, height,
		      background, gradient,
		      downloaddir, frame)
{
  pluginID += "obj";

  document.write('<script event="Initialised()" for="' + pluginID + '">' +
		 'NSInitialised("' + pluginID + '","' + filename + '");' +
		 '</script>');

  document.write('<script event="LoadEdComplete()" for="' + pluginID + '">' +
		 'NSLoadEdComplete("' + pluginID + '","' + viewstate + '");' +
		 '</script>');

  var versionstrings = 'i486_nt_ie/pvapplite_ie.cab/8,0,40,13;x86e_win64_ie/pvapplite_ie.cab/8,0,40,13';

  PV_InsertPlugin(width, height, downloaddir, versionstrings, pluginID);
}

function pview_OnClick(pluginID, view, frame)
{
  pluginID += "obj";

  NSOnClick(pluginID, view);
}


//*****************************************************************************
// IsoView
//*****************************************************************************

function iview_Insert(id, uri, view,
		      width, height, background, gradient,
		      downloaduri, frame)
{
  id += "obj";

  if (parent.iObjectName == id && parent.iViewState != '') {
    view = parent.iViewState;
    parent.iObjectName = "";
  }

  if (view != '')
    uri += '#name(isovp_' + view + ', viewcontext)';
  else
    uri += '#name(isovp_$EXTENT, viewcontext)';

  var btns = 1 + 2 + 4 + 0x20 + 0x40 + 0x80 +
             0x200000 + 0x400000 + 0x800000 + 0x1000000;

  var initscript =
    '<script event="InitFinished()"' +
    '        for=' + '"' + id + '">' + 
    id + '.Iso7ConfigTools(1, ' + btns + ', 0, 0, false, false);' +
    id + '.Iso3OpenFile("' + uri + '");' +
    '</script>';

  document.write(initscript);

  var codebasescript = '';

  if (downloaduri != '')
    codebasescript = 'codebase="' + downloaduri + '"';

  var objscript =
    '<object id="' + id + '" ' +
    '        classid="CLSID:865B2280-2B71-11D1-BC01-006097AC382A" ' + 
    codebasescript +
    '        width="' + width + '" ' +
    '        height="' + height + '">' +
    '</object>';

  document.write(objscript);
}

function iview_OnClick(id, view, frame)
{
  id += "obj";

  var ctrl = document.getElementById(id);
  if (ctrl != null)
    {
      ctrl.ViewPort = view;
    }
  else
    {
      parent.iObjectName = id;
      parent.iViewState = view;
    }
}
